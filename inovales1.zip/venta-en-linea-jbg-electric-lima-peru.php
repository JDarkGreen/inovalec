
<!-- Incluir el header principal estilos cargados y demás -->
<?php  
  //activar item
$active = 5;
  //setear el título
$title = "JBG ELECTRIC | Historia de la empresa, Eventos, Equipos Electricos Peru,  repuestos electricos,  productos por linea, materiales instalaciones electricas industrial, automatizacion industrial, conductores electricos, equipo de media tension control y proteccion, equipos de seguridad y maniobra, ferreteria de electrificacion, iluminacion peru, instrumentos de medicion, linea conduit, materiales aislantes, materiales para instalaciones residenciales, pararrayos, sistema puesta tierra y afines, seguridad industrial lima peru, repuestos electricos lima peru, material construccion electricos,  productos por marcas 3m, lima abb abro aibar, bremas  celsa cirmarker lima, coel crc elcope lima, exosolda general electric indeco peru, kss legrand leviton peru, loctite lumnia mennekes peru, schneider electric siemens peru, talma ide termoweld lima, solera jsl santos peru dexson tecnoflex ls repuestos peru, tecnofil bticino orbis metal&a opalux hurricane lima peru";

  //incluir plantilla header
include('includes/main-header.php');

?>

<!-- Incluir Banner de Pagina -->
<?php  
$title_page = "ventas en linea";
$ruta_img   = "images/banner/ventas_online_bn_principal.jpg";
include("includes/page/banner.php");
?>

<!-- Linea separadora -->
<span class="line-separator"></span>

<!-- sectionHistoria Pagina Nosotros -->
<section class="sectionPage__ventas">
  <div class="container">
    <div class="row">
      <!-- Titulo -->
      <h2 class="sectionCommon__title-page text-uppercase">ventas en línea</h2>
      
      <!-- Sección de Formulario -->
      <div id="content_form">
        <form name="formulario" id="formulario" method="post">

          <div class="col s12 m6">
            <label class="form_lab"><p>Empresa:</p></label>
            <input type="text" maxlength="30" size="20" id="empresa1" class="validate[required] borde_texto" name="empresa1" /> 
            <!-- Salto --> <br/>
            <label class="form_lab"> <p>Telefono:</p> </label>
            <input type="text" maxlength="10" size="20" id="telefono1" class="validate[required,custom[number],minSize[6]] borde_telefono" name="telefono1" />           
          </div><!-- /.col s12 m6 -->

          <div class="col s12 m6">
            <label class="form_lab"> <p>E-mail:</p> </label>
            <input type="text" id="email" class="validate[required,custom[email] borde_texto" size="20" name="email" />   
            <!-- Salto --> <br/>
            <label class="form_lab"><p>Fecha:</p> </label>
            <input type="text" id="fecha" class="validate[required] borde_fecha" size="20" maxlength="30" name="fecha" value="<?php echo date('d/m/Y'); ?>" />  
          </div><!-- /.col s12 m6 -->

          <!-- Cotizacion -->
          <section class="col s12">
            <table border="0" align="center" cellpadding="0" cellspacing="0" id="table">
              <tr class="bg-cotizador">
                <td><span>Cantidad</span></td>
                <td><span>Producto</span></td>
                <td><span>Marca</span></td>
              </tr>
              <tr><td height="2" colspan="2"></td></tr>
              <tr>
                <td><input name="cantidad[]" type="text" class="input_text_cantidad" /></td>
                <td><input type="text" name="producto[]" class="input_text_producto" /></td>
                <td>
                  <select name="marcas[]" class="select_box">
                    <option value="">--Marca--</option>
                    <?php 
                      $sql_marcas  = "SELECT * FROM marcas ORDER BY nombre_marca ASC";
                      $rpta_marcas = query($sql_marcas) or die(mysql_error());
                      $row_marcas = fetch_array($rpta_marcas);

                      foreach( $row_marcas as $marca ) : ?>
                        <option value="<?= $marca['nombre_marca'] ?>"><?= $marca['nombre_marca']  ?></option>
                    <?php endforeach; ?>           
                  </select>
                </td>
              </tr>
            </table>            
          </section><!-- /.col s12 -->




            
                    </div>
                     
                     <label id="estado"></label>
                     <div class="botones">
                        <button type="button" value="" id="botonagregar" name="enviar">Agregar</button>
                        <div id="botoncotizarVenta" style="float:right;"><button type="submit" value="" id="botoncotizar" name="cotizar">Solicitar cotización</button></div>
                     </div>
              

                    <script type="text/javascript" src="js/jquery.carouFredSel-6.0.5-packed.js"></script>
                    <script src="js/jquery.validationEngine.js" type="text/javascript"></script>
                    <script src="js/jquery.validationEngine-es.js" type="text/javascript"></script>       
                    <script type="text/javascript">
                    <!--
                    jQuery(document).ready(function($){
                        jQuery('#formulario').validationEngine({
                            scroll: false,
                            promptPosition: "topRight",
                            onValidationComplete: function(form, status)
                            {
                                if ( jQuery('#formulario').validationEngine('validate')==true)
                                {
                                    jQuery.post('enviarsolicitudventa.php', jQuery('#formulario').serialize(), function(data) {
                                        jQuery('#estado').html(data);
                                        jQuery('#estado').show();                 
                                        jQuery('#empresa1').val('');        
                                        jQuery('#email').val('');
                                        jQuery('#telefono1').val('');                   
                                                        
                                    });
                                    
                                    jQuery.post('mostrar-boton.php', jQuery('#formulario').serialize(), function(data) {
                                        $('#botoncotizarVenta').html(data);
                                        $('#botoncotizarVenta').show(); 
                                                        
                                    });               
                                    
                                    
                                    
                                }
                            }
                        });
                    });
                    --> 
                    </script>                
                    
                    <script type="text/javascript" src="js/menu.js"></script>
                    <script type="text/javascript" src="js/swfobject2.js"></script>
                    <script type="text/javascript">
                    
                    jQuery(document).ready(function($) {
                    
                        jQuery("#m6").addClass("activaventas");    
                    
                    });

                    </script>
                    <!-- fecha y hora -->
                    <script type="text/javascript" src="js/fecha_hora.js"></script>
                    <!-- -->                    
                      <script type="text/javascript">
                        jQuery("#botonagregar").click(function ($) {
                                var row = "<tr>"
                                            +"<td height='2'></td>"
                                          +"</tr>"  
                                          +"<tr>" 
                                            + "<td><input name='cantidad[]' type='text' class='input_text_cantidad' /></td>"
                                            + "<td><input type='text' name='producto[]' class='input_text_producto' /></td>"
                                            + "<td><select name='marcas[]' class='select_box'>"
                                               + "<option value=''>--Marca--</option>"
                                               + "<?php
                                                        $sql_marcas  = "SELECT * FROM marcas ORDER BY nombre_marca ASC";
                                                        $rpta_marcas = query($sql_marcas) or die(mysql_error());
                                                        
                                                        while($row_marcas = fetch_array($rpta_marcas))
                                                        {
                                                            echo "<option value=".$row_marcas['nombre_marca'].">".$row_marcas['nombre_marca']."</option>";  
                                                        }
                                                      
                                                  ?>"
                                               + "</select>"
                                            + "</td>"
                                            + "<td><button>X</button></td>"
                                        + "</tr>";
                                jQuery("#table").append(row);
                            });
                        
                        jQuery("#table").on("click", "button", function($) {
                           jQuery(this).closest("tr").remove(); 
                           jQuery('#table tr:last').remove();
                        });
                        
                     </script>                        
                  </form>                     
            
                </div><!-- content_form -->

    </div><!-- /.row -->
  </div><!-- /.container -->
</section><!-- /.sectionPage__nosotros__historia -->

<!-- Linea separadora -->
<span class="line-separator"></span>

<!-- Seccion incluir marcas -->
<section class="sectionMarcas">
  <div class="container">
    <div id="owl-carousel-marcas" class="">
      <div class="item"><img src="images/carousel-marcas/marca-3m-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-abb-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-abro-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-aibar-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-amp-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-bahaco-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-bticino-jbg.jpg" alt="" class="responsive-img" /></div>
    </div><!-- /.owl-carousel -->
  </div><!-- /.container -->
</section><!-- /sectionMarcas -->

<!-- Incluir demás librerias javascript en el main footer -->
<?php include("includes/main-footer.php") ?>