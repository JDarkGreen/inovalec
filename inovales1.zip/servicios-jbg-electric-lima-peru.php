
<!-- Incluir el header principal estilos cargados y demás -->
<?php  
  //activar item
  $active = 4;
  //setear el título
  $title = "JBG ELECTRIC | Historia de la empresa, Eventos, Equipos Electricos Peru,  repuestos electricos,  productos por linea, materiales instalaciones electricas industrial, automatizacion industrial, conductores electricos, equipo de media tension control y proteccion, equipos de seguridad y maniobra, ferreteria de electrificacion, iluminacion peru, instrumentos de medicion, linea conduit, materiales aislantes, materiales para instalaciones residenciales, pararrayos, sistema puesta tierra y afines, seguridad industrial lima peru, repuestos electricos lima peru, material construccion electricos,  productos por marcas 3m, lima abb abro aibar, bremas  celsa cirmarker lima, coel crc elcope lima, exosolda general electric indeco peru, kss legrand leviton peru, loctite lumnia mennekes peru, schneider electric siemens peru, talma ide termoweld lima, solera jsl santos peru dexson tecnoflex ls repuestos peru, tecnofil bticino orbis metal&a opalux hurricane lima peru";

  //incluir plantilla header
  include('includes/main-header.php');

?>

<!-- Incluir Banner de Pagina -->
<?php  
    $title_page = "servicio";
    $ruta_img   = "images/banner/servicios_bn_principal.jpg";
    include("includes/page/banner.php");
?>

<!-- Linea separadora -->
<span class="line-separator"></span>

<!-- sectionHistoria Pagina Nosotros -->
<section class="sectionPage__servicio">
    <div class="container">
      
      <!-- Titulo -->
      <h2 class="sectionCommon__title-page text-uppercase center">principales</h2>

      <div class="row">
        <!-- Articulos 1 -->
        <article class="sectionPage__servicio__article col s12 m4">
          <!-- Imagen -->
          <figure><img src="images/pages/servicio/servicio_1.jpg" alt="servicio-1" class="responsive-img" /></figure>
          <!-- Titulo  -->
          <h3 class="article-title text-uppercase">servicio 1</h3>
          <!-- Parrafo -->
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
        </article><!-- /.sectionPage__servicio__article -->
        <!-- Articulos 1 -->
        <article class="sectionPage__servicio__article col s12 m4">
          <!-- Imagen -->
          <figure><img src="images/pages/servicio/servicio_2.jpg" alt="servicio-2" class="responsive-img" /></figure>
          <!-- Titulo  -->
          <h3 class="article-title text-uppercase">servicio 2</h3>
          <!-- Parrafo -->
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
        </article><!-- /.sectionPage__servicio__article -->
        <!-- Articulos 1 -->
        <article class="sectionPage__servicio__article col s12 m4">
          <!-- Imagen -->
          <figure><img src="images/pages/servicio/servicio_3.jpg" alt="servicio-3" class="responsive-img" /></figure>
          <!-- Titulo  -->
          <h3 class="article-title text-uppercase">servicio 3</h3>
          <!-- Parrafo -->
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
          <p class="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore aut pariatur eos autem fugiat harum temporibus ut eius, hic esse. Quisquam enim quia debitis quidem aliquam odio. Est provident, illo!</p>
        </article><!-- /.sectionPage__servicio__article -->
      </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.sectionPage__nosotros__historia -->

<!-- Linea separadora -->
<span class="line-separator"></span>

<!-- Seccion incluir marcas -->
<section class="sectionMarcas">
  <div class="container">
    <div id="owl-carousel-marcas" class="">
      <div class="item"><img src="images/carousel-marcas/marca-3m-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-abb-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-abro-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-aibar-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-amp-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-bahaco-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-bticino-jbg.jpg" alt="" class="responsive-img" /></div>
    </div><!-- /.owl-carousel -->
  </div><!-- /.container -->
</section><!-- /sectionMarcas -->

<!-- Incluir demás librerias javascript en el main footer -->
<?php include("includes/main-footer.php") ?>