
<!-- Incluir el header principal estilos cargados y demás -->
<?php  
  //activar item
  $active = 8;
  //setear el título
  $title = "JBG ELECTRIC | Contáctenos para solicitar equipos Electricos Peru,  repuestos electricos,  productos por linea, materiales instalaciones electricas industrial, automatizacion industrial, conductores electricos, equipo de media tension control y proteccion, equipos de seguridad y maniobra, ferreteria de electrificacion, iluminacion peru, instrumentos de medicion, linea conduit, materiales aislantes, materiales para instalaciones residenciales, pararrayos, sistema puesta tierra y afines, seguridad industrial lima peru, repuestos electricos lima peru, material construccion electricos,  productos por marcas 3m, lima abb abro aibar, bremas  celsa cirmarker lima, coel crc elcope lima, exosolda general electric indeco peru, kss legrand leviton peru, loctite lumnia mennekes peru, schneider electric siemens peru, talma ide termoweld lima, solera jsl santos peru dexson tecnoflex ls repuestos peru, tecnofil bticino orbis metal&a opalux hurricane lima peru";

  //incluir plantilla header
  include('includes/main-header.php');

?>

<!-- Incluir Banner de Pagina -->
<?php  
    $title_page = "contáctenos";
    $ruta_img   = "images/banner/contacto_bn_principal-.jpg";
    include("includes/page/banner.php");
?>

<!-- Linea separadora -->
<span class="line-separator"></span>

<!-- sectionHistoria Pagina Contacto -->
<section class="sectionPage__contacto">
    <div class="container">
    
      <div class="row">
          <div class="col s12 m6">
            <!-- Seccion de datos generales -->
            <section class="sectionPage__contacto__datos">
              <!-- Titulo -->
              <h2 class="sectionPage__contacto__title sectionCommon__title-page text-uppercase"><strong>datos generales</strong>
                <!-- Linea separadora --><span class="line-blue"></span>
              </h2>
              <!-- Parrafo -->
              <p class="sectionPage__contacto__paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum quibusdam ullam blanditiis, magnam dolores ea odio labore pariatur fugiat repellat quo sed, mollitia inventore adipisci est illo officia architecto error.</p>
              <!-- Lista de datos -->
              <ul class="sectionPage__contacto__list">
                <!-- Direccion  -->
                <li>
                  <!-- Icono -->
                  <i class="icon left"><img src="images/contacto/iconos_contacto_direccion.png" alt="direccion" class="responsive-img" /></i>
                  <!-- Texto -->
                  <h3 class="text-uppercase">Dirección: </h3>
                  <p>t nam illum eos, sunt reprehenderit.</p>
                  <!-- Clearfix --> <div class="clearfix"></div>
                </li>
                <!-- Telefono  -->
                <li>
                  <!-- Icono -->
                  <i class="icon left"><img src="images/contacto/iconos_contacto_telefono.png" alt="telefono" class="responsive-img" /></i>
                  <!-- Texto -->
                  <h3 class="text-uppercase">teléfono: </h3>
                  <p>t nam illum eos, sunt reprehenderit.</p>
                  <!-- Clearfix --> <div class="clearfix"></div>
                </li>
                <!-- Mail -->
                <li>
                  <!-- Icono -->
                  <i class="icon left"><img src="images/contacto/iconos_contacto_mail.png" alt="mail" class="responsive-img" /></i>
                  <!-- Texto -->
                  <h3 class="text-uppercase">Email: </h3>
                  <p>t nam illum eos, sunt reprehenderit.</p>
                  <!-- Clearfix --> <div class="clearfix"></div>
                </li>
              </ul><!-- /.sectionPage__contacto__list -->
            </section><!-- /.sectionPage__contacto__datos -->
          </div><!-- /.col s12 m6 -->
          <div class="col s12 m6">
            <!-- Seccion de personas a contactar -->
            <section class="sectionPage__contacto__personas">
              <!-- Titulo -->
              <h2 class="sectionPage__contacto__title sectionCommon__title-page text-uppercase"><strong>personas a contactar</strong><!-- Linea separadora --><span class="line-blue"></span></h2>
              <!-- Parrafo -->
              <p class="sectionPage__contacto__paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum quibusdam ullam blanditiis, magnam dolores ea odio labore pariatur fugiat repellat quo sed, mollitia inventore adipisci est illo officia architecto error.</p>
              <!-- Lista de personas -->
              <ul class="sectionPage__contacto__list">
                <!-- Direccion  -->
                <li>
                  <!-- Icono -->
                  <i class="icon left"><img src="images/contacto/iconos_contacto_direccion.png" alt="direccion" class="responsive-img" /></i>
                  <!-- Texto -->
                  <h3 class="text-uppercase">Dirección: </h3>
                  <p>t nam illum eos, sunt reprehenderit.</p>
                  <!-- Clearfix --> <div class="clearfix"></div>
                </li>
                <!-- Telefono  -->
                <li>
                  <!-- Icono -->
                  <i class="icon left"><img src="images/contacto/iconos_contacto_telefono.png" alt="telefono" class="responsive-img" /></i>
                  <!-- Texto -->
                  <h3 class="text-uppercase">teléfono: </h3>
                  <p>t nam illum eos, sunt reprehenderit.</p>
                  <!-- Clearfix --> <div class="clearfix"></div>
                </li>
                <!-- Mail -->
                <li>
                  <!-- Icono -->
                  <i class="icon left"><img src="images/contacto/iconos_contacto_mail.png" alt="mail" class="responsive-img" /></i>
                  <!-- Texto -->
                  <h3 class="text-uppercase">Email: </h3>
                  <p>t nam illum eos, sunt reprehenderit.</p>
                  <!-- Clearfix --> <div class="clearfix"></div>
                </li>
              </ul><!-- /.sectionPage__contacto__list -->
            </section><!-- /.sectionPage__contacto__personas -->
          </div><!-- /.col s12 m6 -->

      </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.sectionPage__contacto -->

<!-- Seccion del mapa -->
<section class="sectionPage__contacto__mapa">
  <div id="canvas-map"></div>
</section>

<!-- Linea separadora -->
<span class="line-separator"></span>

<!-- Seccion incluir marcas -->
<section class="sectionMarcas">
  <div class="container">
    <div id="owl-carousel-marcas" class="">
      <div class="item"><img src="images/carousel-marcas/marca-3m-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-abb-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-abro-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-aibar-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-amp-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-bahaco-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-bticino-jbg.jpg" alt="" class="responsive-img" /></div>
    </div><!-- /.owl-carousel -->
  </div><!-- /.container -->
</section><!-- /sectionMarcas -->

  <!-- Google  maps -->  
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5TPL8p63MmkT7HKOfHGlFFKaZbpelFnM" type="text/javascript"></script>

<!-- Script de Mapa -->
<script type="text/javascript">
  <?php  
    $lat = -14.916278;
    $lng = -70.196357;
  ?>
    var map;
    var lat = <?= $lat ?>;
    var lng = <?= $lng ?>;
    function initialize() {
      //crear mapa
      map = new google.maps.Map(document.getElementById('canvas-map'), {
        center: {lat: lat, lng: lng},
        zoom  : 17
      });
      //infowindow
      var infowindow    = new google.maps.InfoWindow({
        content: <?= "'" . "Inovalec" . "'" ?>
      });
      //crear marcador
      marker = new google.maps.Marker({
        map      : map,
        draggable: false,
        animation: google.maps.Animation.DROP,
        position : {lat: lat, lng: lng},
        title    : "Inovalec"
      });
      //marker.addListener('click', toggleBounce);
      marker.addListener('click', function() {
        infowindow.open( map, marker);
      });
    }
    google.maps.event.addDomListener(window, "load", initialize);
</script>

<!-- Incluir demás librerias javascript en el main footer -->
<?php include("includes/main-footer.php") ?>