<div id="menu">

<ul id="nav_menu">
     <li><a href="index.php" id="m1" class="home">Inicio</a></li>
     <li class="sep"></li>
     <li><a href="jbg-electric-historia-empresa-lima-peru.php#nosotros" id="m2" class="empresa">Empresa</a></li>
     <li class="sep"></li>
     <li><a href="javascript:void(0);"class="productos" id="m3">Productos</a>
        <ul class="submenu">
           <li><a href="marcas-jbg-electric-lima-peru.php#marca" id="m3">Por marca</a></li>
           <li><a href="linea-jbg-electric-lima-peru.php#lineas" id="m3">Por linea</a></li>
        </ul>
     </li>
     <li class="sep"></li>
     <li><a href="servicios-jbg-electric-lima-peru.php#servicio" id="m4" class="servicios">Servicios</a></li>
     <li class="sep"></li>
     <li><a href="nuestras-marcas-jbg-electric-lima-peru.php#nuestras_marcas" id="m5" class="marcas">Marcas</a></li>
     <li class="sep"></li>
     <li><a href="venta-en-linea-jbg-electric-lima-peru.php#ventas_linea" id="m6" class="ventas">Ventas en linea</a></li>
     <li class="sep"></li>    
     <li><a href="javascript:void(0);" id="m7" class="eventos">Eventos</a>
        <ul class="submenu">
            <li><a href="promociones-jbg-electric-lima-peru.php?categoria=1&subcategoria=2#eventos">PROMOCIONES</a></li>
            <li><a href="noticias-jbg-electric-lima-peru.php?categoria=1&subcategoria=3#eventos">NOTICIAS</a></li>            
        </ul>     
     </li>
     <li class="sep"></li>
     <li><a href="contactenos-jbg-electric-lima-peru.php#contactos" id="m8" class="contactenos">Contactenos</a></li>
  </ul>          

</div><!-- menu -->