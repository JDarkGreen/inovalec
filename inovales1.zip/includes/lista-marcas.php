<div id="portada_marcas">
    <h1>nuestras marcas</h1>
    <div id="lista_marcas">
        <div class="jMyCarousel">
            <ul id="scroller">
                <li><img src="images/carousel-marcas/marca-3m-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-abb-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-abro-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-aibar-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-amp-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-bahaco-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-bremas-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-bticino-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-coel-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-crc-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-elcope-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-fluke-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-general-electric-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-ide-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-indeco-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-legrand-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-leviton-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-mennekes-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-miguelez-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-pavco-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-roker-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-schneider-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-sika-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-solera-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-stanley-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-talmasa-jbg.jpg" /></li>
                <li><img src="images/carousel-marcas/marca-thermoweld-jbg.jpg" /></li>
           </ul>
        </div>
    
    </div><!-- lista_marcas -->

</div><!-- portada_marcas -->