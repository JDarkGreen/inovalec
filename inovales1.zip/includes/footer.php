<div id="footer">
  <div id="footer_contenido">
    <div id="footer_izq">
      <p>Derechos Reservados 2013</p>
      <p>jbgelectric@gmail.com</p>
    </div>
    <!-- footer_izq -->
    
    <div id="footer_der">
      <p>Dirección: Jr. Azangaro Nro. 970 Int.183</p>
	  <p>Cercado de lima</p>
      <p>Telf: 427-3928</p>
      <p>Cel: 993 516 382</p>
<!--      <p>Nextel: 41*151*8870</p>-->
    </div>
    <!-- footer_der --> 
    
  </div>
  <!-- footer_contenido --> 
  
</div><!-- footer-->
    