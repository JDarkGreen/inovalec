<div id="header">
    <div id="header_logo"></div>
    <!-- header_logo -->
    <div id="header_der">
     <div id="Fecha_Reloj">
     </div>
     <div id="redes_sociales">
        <p>Siguenos en:</p>
     </div>
     <ul class="list-services">
        <li><a target="_blank" title="facebook" class="tooltips" href="http://www.facebook.com/"></a></li>
        <li class="item-1"><a target="_blank" title="twitter" class="tooltips" href="http://www.twitter.com/"></a></li>
        <li class="item-2"><a target="_blank" title="youtube" class="tooltips" href="http://www.youtube.com/"></a></li>
     </ul>
    </div><!-- header_der -->          

</div><!-- header -->