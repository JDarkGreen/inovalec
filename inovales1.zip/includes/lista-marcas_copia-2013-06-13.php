<div id="portada_marcas">
    <h1>nuestras marcas</h1>
    <div id="lista_marcas">
        <div class="image_carousel_portada">
            <div id="foo3">
                <img src="images/carousel-marcas/marca-3m-jbg.jpg" />
                <img src="images/carousel-marcas/marca-abb-jbg.jpg" />
                <img src="images/carousel-marcas/marca-abro-jbg.jpg" />
                <img src="images/carousel-marcas/marca-aibar-jbg.jpg" />
                <img src="images/carousel-marcas/marca-amp-jbg.jpg" />
                <img src="images/carousel-marcas/marca-bahaco-jbg.jpg" />
                <img src="images/carousel-marcas/marca-bremas-jbg.jpg" />
                <img src="images/carousel-marcas/marca-bticino-jbg.jpg" />
                <img src="images/carousel-marcas/marca-coel-jbg.jpg" />
                <img src="images/carousel-marcas/marca-crc-jbg.jpg" />
                <img src="images/carousel-marcas/marca-elcope-jbg.jpg" />
                <img src="images/carousel-marcas/marca-fluke-jbg.jpg" />
                <img src="images/carousel-marcas/marca-general-electric-jbg.jpg" />
                <img src="images/carousel-marcas/marca-ide-jbg.jpg" />
                <img src="images/carousel-marcas/marca-indeco-jbg.jpg" />
                <img src="images/carousel-marcas/marca-legrand-jbg.jpg" />
                <img src="images/carousel-marcas/marca-leviton-jbg.jpg" />
                <img src="images/carousel-marcas/marca-mennekes-jbg.jpg" />
                <img src="images/carousel-marcas/marca-miguelez-jbg.jpg" />
                <img src="images/carousel-marcas/marca-pavco-jbg.jpg" />
                <img src="images/carousel-marcas/marca-roker-jbg.jpg" />
                <img src="images/carousel-marcas/marca-schneider-jbg.jpg" />
                <img src="images/carousel-marcas/marca-sika-jbg.jpg" />
                <img src="images/carousel-marcas/marca-solera-jbg.jpg" />
                <img src="images/carousel-marcas/marca-stanley-jbg.jpg" />
                <img src="images/carousel-marcas/marca-talmasa-jbg.jpg" />
                <img src="images/carousel-marcas/marca-thermoweld-jbg.jpg" />
                <img src="images/carousel-marcas/marca-vainsa-jbg.jpg" />                       
           </div> 
            <div class="clearfix"></div>
            <a class="prev_portada" id="foo3_prev" href="#"><span>prev</span></a> 
            <a class="next_portada" id="foo3_next" href="#"><span>next</span></a>                      
        
        </div><!-- image_carousel_portada -->
    
    </div><!-- lista_marcas -->

</div><!-- portada_marcas -->