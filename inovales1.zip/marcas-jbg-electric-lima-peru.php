<?php

	include("includes/conexion.php");
	include("includes/funciones.php");
	
	$cn = Conexion();
	
	//  funcion para mostrar las promociones.
	$rpta_listar_promocion = listar_promociones(1);
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/estilos.css" />
<link rel="stylesheet" type="text/css" href="css/reset.css" />
<link rel="stylesheet" type="text/css" href="css/examples.css" />
<link rel="stylesheet" type="text/css" href="css/examples_portada.css" />
<link rel="stylesheet" type="text/css" href="css/jquery.simplyscroll.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<!-- jquery no conflict -->
<script type="text/javascript">
	$.noConflict();
</script>
<!-- jquery carousel -->
<script type="text/javascript" src="js/jquery.simplyscroll.js"></script>
<script type="text/javascript">
	jQuery(function($) {
		jQuery("#scroller").simplyScroll({
			auto: true,
			speed: 3
		});
	});
</script>
<script type="text/javascript" src="js/jquery.carouFredSel-6.0.5-packed.js"></script>
<script type="text/javascript" src="js/home.js"></script>
<!--<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>-->
<script type="text/javascript" src="js/menu.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($) {
	jQuery("#m3").addClass("activaproductos");    
});

</script>
<!-- fecha y hora -->
<script type="text/javascript" src="js/fecha_hora.js"></script>
<!-- -->
<script type="text/javascript" src="js/swfobject2.js"></script>
<title>JBG ELECTRIC | Marcas para equipos electricos peru,  repuestos electricos,  productos por linea, materiales instalaciones electricas industrial, automatizacion industrial, conductores electricos, equipo de media tension control y proteccion, equipos de seguridad y maniobra, ferreteria de electrificacion, iluminacion peru, instrumentos de medicion, linea conduit, materiales aislantes, materiales para instalaciones residenciales, pararrayos, sistema puesta tierra y afines, seguridad industrial lima peru, repuestos electricos lima peru, material construccion electricos,  productos por marcas 3m, lima abb abro aibar, bremas  celsa cirmarker lima, coel crc elcope lima, exosolda general electric indeco peru, kss legrand leviton peru, loctite lumnia mennekes peru, schneider electric siemens peru, talma ide termoweld lima, solera jsl santos peru dexson tecnoflex ls repuestos peru, tecnofil bticino orbis metal&a opalux hurricane lima peru</title>
</head>

<body onload="actualizaReloj()">
<div id="contenido_bg">

    <div id="contenido" class="limpiar">

        <div id="header_bg">
            
			<?php
                include("includes/header2.php");
            
            ?>
            <!-- header -->
            
			<?php
            	include("includes/header.php");
			?>                
                    
        </div><!-- header_bg -->
        
        <div id="cuerpo">
        	
          <div id="banner"> </div>
          <!-- banner -->
            
           <div id="cuerpo_marcas">           
            	<h1 id="marca">Marcas</h1>
                <div id="form_buscar-1">
                    <form action="jbg-electric-resultados-busqueda-lima-peru.php" method="post" id="frmbuscar" name="frmbuscar">
                    	<p style="padding-right:8px;">Buscar producto</p>
                        <p style="margin-top:10px;"><input type="text" value="" class="borde_texto" id="buscar" name="buscar"></p>
                    </form>                    
                </div>
                
                <div id="contenido_marcas">
                
                <?php
        
                   listar_marcas();	
                
                ?>
        
               </div>                
                
            </div><!-- cuerpo_marcas -->
            
			<?php
                include("includes/lista-marcas.php");
                
            ?>
        
       </div><!-- cuerpo -->
       
		<?php
            include("includes/footer.php");
        
        ?>
       
    </div><!-- contenido -->



</div><!-- contenido_bg -->

</body>
<script type="text/javascript">

var so = new SWFObject("swf/banner.swf","flores","950","383","9");
 so.addParam("wmode", "transparent");
 so.addParam("menu", "false");
 so.write("banner");

</script>
<script type="text/javascript">

var so = new SWFObject("swf/logo.swf","miguelangoma","377","153","9");
 so.addParam("wmode", "transparent");
 so.addParam("menu", "false");
 so.write("header_logo");
</script>
</html>