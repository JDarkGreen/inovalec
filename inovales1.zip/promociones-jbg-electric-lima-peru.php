<?php

	include("includes/conexion.php");
	include("includes/funciones.php");
	
	$cn = Conexion();
	
	$sql_promocion  = "SELECT p.*, e.* FROM eventos e, promociones p 
					   WHERE e.idcategoria = p.idcategoria
					   AND p.subcategoria = '".$_GET['subcategoria']."' ORDER BY idpromocion DESC";
	$rpta_promocion = query($sql_promocion) or die(mysql_error());
	
	// mostrar el evento por defecto.
	
	$sql_detallepromocion  = "SELECT p.*, e.* FROM eventos e, promociones p 
					 		  WHERE e.idcategoria = p.idcategoria
					 		  AND p.subcategoria = '".$_GET['subcategoria']."'
							  ORDER BY idpromocion DESC";
	$rpta_detallepromocion = query($sql_detallepromocion) or die(mysql_error());
	$row_detallepromocion  = fetch_array($rpta_detallepromocion);	
	
	// contenido de la subcategoria.
	$sql_contenidosubseccion   = "SELECT e.categoria as subcat FROM eventos e WHERE e.idcategoria='".$_GET['subcategoria']."'";
	$rpta_contenidosubseccion  = query($sql_contenidosubseccion) or die(mysql_error());
	$fila_contenidosubseccion  = fetch_array($rpta_contenidosubseccion);	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/estilos.css" />
<link rel="stylesheet" type="text/css" href="css/reset.css" />
<link rel="stylesheet" type="text/css" href="css/jquery.simplyscroll.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<!-- jquery no conflict -->
<script type="text/javascript">
	$.noConflict();
</script>
<!-- jquery carousel -->
<script type="text/javascript" src="js/jquery.simplyscroll.js"></script>
<script type="text/javascript">
	jQuery(function($) {
		jQuery("#scroller").simplyScroll({
			auto: true,
			speed: 3
		});
	});
</script>
<script type="text/javascript" src="js/jquery.carouFredSel-6.0.5-packed.js"></script>
<script type="text/javascript" src="js/home.js"></script>
<!--<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>-->
<script type="text/javascript" src="js/menu.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($) {
	jQuery("#m7").addClass("activaeventos");
	// jQuery("#m1").removeClass("removehome");    
});

</script>
<!-- fecha y hora -->
<script type="text/javascript" src="js/fecha_hora.js"></script>
<!-- -->
<script type="text/javascript" src="js/swfobject2.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<title>JBG ELECTRIC | Promociones de repuestos electricos,  productos por linea, materiales instalaciones electricas industrial, automatizacion industrial, conductores electricos, equipo de media tension control y proteccion, equipos de seguridad y maniobra, ferreteria de electrificacion, iluminacion peru, instrumentos de medicion, linea conduit, materiales aislantes, materiales para instalaciones residenciales, pararrayos, sistema puesta tierra y afines, seguridad industrial lima peru, repuestos electricos lima peru, material construccion electricos,  productos por marcas 3m, lima abb abro aibar, bremas  celsa cirmarker lima, coel crc elcope lima, exosolda general electric indeco peru, kss legrand leviton peru, loctite lumnia mennekes peru, schneider electric siemens peru, talma ide termoweld lima, solera jsl santos peru dexson tecnoflex ls repuestos peru, tecnofil bticino orbis metal&a opalux hurricane lima peru</title>
</head>

<body onload="actualizaReloj()">
<div id="contenido_bg">

    <div id="contenido" class="limpiar">

        <div id="header_bg">
            
			<?php
                include("includes/header2.php");
            
            ?>
            <!-- header -->
            
			<?php
            	include("includes/header.php");
			?>                
                    
        </div><!-- header_bg -->
        
        <div id="cuerpo">
        	
          <div id="banner"> </div>
          <!-- banner -->

          <div id="cuerpo_eventos">
         
              <h1 id="eventos">PROMOCIONES</h1>
              
              <div id="eventos2">
                  <div id="bg-corned-1"></div>
                  <div id="lista_eventos">
                      <ul>
                          <?php
                            $i = 1;
                            $row_evento = fetch_array($rpta_promocion);

                            foreach( $row_evento as $evento ) :
                          ?>
                            <li><a id="idx_<?= $i; ?>" href="javascript:void(0);" class="all" onclick="cargar_promocion('ver-detalle-promocion.php?idpromocion=<?= $evento['idpromocion']; ?>');"><?= $evento['titulo_promocion']; ?></a>
                            </li>        
                         <?php $i++; endforeach; ?>
                     </ul>
                  </div><!-- lista_eventos -->
                  <div id="bg-corned-2"></div>
              </div>
              
              <div id="contenido_evento">
                <h2><?php echo $row_detallepromocion[0]['titulo_promocion']; ?></h2>
                    <img src="images/productos/promociones/<?php echo $row_detallepromocion[0]['imagen_promocion']; ?>" style="float:left; margin-left: 30px;" /> 
                    <div style="float:right;">
						<?php echo $row_detallepromocion[0]['descripcion']; ?>      		
                    </div>
              </div>
              
           </div><!-- cuerpo_eventos -->
            
		   <?php
           		include("includes/lista-marcas.php");
				
		   ?>
        
       </div><!-- cuerpo -->
       
		<?php
            include("includes/footer.php");
        
        ?>
       
    </div><!-- contenido -->



</div><!-- contenido_bg -->

</body>
<script type="text/javascript">

var so = new SWFObject("swf/banner.swf","flores","950","383","9");
 so.addParam("wmode", "transparent");
 so.addParam("menu", "false");
 so.write("banner");

</script>
<script type="text/javascript">

var so = new SWFObject("swf/logo.swf","miguelangoma","377","153","9");
 so.addParam("wmode", "transparent");
 so.addParam("menu", "false");
 so.write("header_logo");
</script>
</html>