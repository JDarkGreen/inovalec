<?php

	include("includes/conexion.php");
	include("includes/funciones.php");
	
	$cn = Conexion();
	
	$subseccion = ($_GET['idsubnivel']=='')?$subseccion:'';
	$texto      = ($_GET['idmarca']=='')?'linea':'marca';
	
	// para las marcas.
	
	$idseccion	    = $_GET['idseccion'];
	$idmarca		= $_GET['idmarca'];	
	$nom_marca      = $_GET['nom_marca'];
	$seccion		= $_GET['seccion'];
	$subseccion1	= $_GET['subseccion'];		
	$subnivel 		= $_GET['subnivel'];		
	
	// llamo a la funcion productos para mostrar la lista de los items registrados.
	$resultado = productos($subseccion);
	
	$sql_submarcas  = "SELECT p.*, s.*, m.*, s.seccion as subseccion FROM productos p, secciones s, marcas m
						WHERE p.idseccion = s.idseccion
						AND p.idmarca = m.idmarca
						AND p.idseccion = '".$idseccion."'
						AND p.idmarca = '".$idmarca."'";
	$rpta_submarcas = query($sql_submarcas) or die(mysql_error());
	$row_submarca   = fetch_array($rpta_submarcas);	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/estilos.css" />
<link rel="stylesheet" type="text/css" href="css/reset.css" />
<link rel="stylesheet" type="text/css" href="css/examples.css" />
<link rel="stylesheet" type="text/css" href="css/examples_portada.css" />
<link rel="stylesheet" type="text/css" href="css/jquery.simplyscroll.css" />
<link rel="stylesheet" type="text/css" href="css/style_m.css" media="screen" />
<link rel="stylesheet" type="text/css" href="css/style_alt_m.css" media="screen" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<!-- jquery no conflict -->
<script type="text/javascript">
	$.noConflict();
</script>
<!-- jquery carousel -->
<script type="text/javascript" src="js/jquery.simplyscroll.js"></script>
<script type="text/javascript" src="js/jMyCarousel.js"></script>
<script type="text/javascript">
	jQuery(function($) {
		jQuery("#scroller").simplyScroll({
			auto: true,
			speed: 3
		});
	});
</script>
<script type="text/javascript" src="js/jquery.carouFredSel-6.0.5-packed.js"></script>
<script type="text/javascript" src="js/home.js"></script>
<!--<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>-->
<script type="text/javascript" src="js/menu.js"></script>
<script src="js/scripts_m.js" type="text/javascript"></script>
<script type="text/javascript">
jQuery(document).ready(function($) {
	jQuery("#m3").addClass("activaproductos");    
});

</script>
<!-- fecha y hora -->
<script type="text/javascript" src="js/fecha_hora.js"></script>
<!-- -->
<script type="text/javascript" src="js/swfobject2.js"></script>
<title>JBG ELECTRIC | Productos para linea de equipos electricos peru,  repuestos electricos,  productos por linea, materiales instalaciones electricas industrial, automatizacion industrial, conductores electricos, equipo de media tension control y proteccion, equipos de seguridad y maniobra, ferreteria de electrificacion, iluminacion peru, instrumentos de medicion, linea conduit, materiales aislantes, materiales para instalaciones residenciales, pararrayos, sistema puesta tierra y afines, seguridad industrial lima peru, repuestos electricos lima peru, material construccion electricos,  productos por marcas 3m, lima abb abro aibar, bremas  celsa cirmarker lima, coel crc elcope lima, exosolda general electric indeco peru, kss legrand leviton peru, loctite lumnia mennekes peru, schneider electric siemens peru, talma ide termoweld lima, solera jsl santos peru dexson tecnoflex ls repuestos peru, tecnofil bticino orbis metal&a opalux hurricane lima peru - Productos por <?php echo $texto; ?> <?php echo $nom_marca; ?>, <?php echo $seccion; ?>, <?php echo $subnivel; ?></title>
</head>

<body onload="actualizaReloj()">
<div id="contenido_bg">

    <div id="contenido" class="limpiar">

        <div id="header_bg">
            
			<?php
                include("includes/header2.php");
            
            ?>
            <!-- header -->
            
			<?php
            	include("includes/header.php");
			?>                
                    
        </div><!-- header_bg -->
        
        <div id="cuerpo">
        	
            <div id="banner"> </div>
            <!-- banner -->
            
            <div id="contenido_productos">
            
              <div id="page-titulo" style="margin-top:15px;">
                <h1 id="lineas"> PRODUCTOS</h1> 
                <div id="form_buscar-1">
                    <form action="jbg-electric-resultados-busqueda-lima-peru.php" method="post" id="frmbuscar" name="frmbuscar">
                    	<p style="padding-right:8px;">Buscar producto</p>
	                    <p><input type="text" value="" class="borde_texto" id="buscar" name="buscar"></p>
                    </form>                    
                </div>                  
              </div>
              
             <div class="encabezados">
             
                <h2 style="margin-top:12px;">
                    <?php echo $nom_marca; ?> -> <?php echo $seccion; ?> -> <?php echo $subnivel; ?>
                </h2>
                <!--<a href="javascript:history.back(1)"><img src="images/atras.png" width="72" height="27" border="0" style="float:right;" /></a> -->
             </div>
             
             <div id="productos">
                   <div class="sidebar">
                    <div class="sidebarPad">
                       <div id="sidebarMenu"><!-- #sidebarMenu -->
                          <div id="sidebarSwitcherContainer" class="center">
                             <input type="button" class="sidebarSwitcher sidebarMarcasBtn " value="LÍNEAS" title="lineas"/>
                             <input type="button" class="sidebarSwitcher sidebarLineasBtn sidebarSwitcherOff" value="MARCAS" title="marcas"/>
                          </div>
                          <div class="separator5"></div>
                          <div id="sidebarScrollable1" class="sidebarMenu">
                             <div id="oaScrollable">
                                <?php
                                    $padre 		 = ($padre == null) ? 'IS NULL' : ' ' . $padre;
                                    $sql_lineas  = "SELECT * FROM secciones WHERE idpadre ".$padre." ORDER BY seccion ASC";
                                    $rpta_lineas = query($sql_lineas,$cn) or die(mysql_error());
                                                            
                                ?>
                                <ul>
                                <?php 
                                    while($row_lineas = fetch_array($rpta_lineas))
                                    {						
                                ?>                        
                                   <li><a href="lista-lineas-subseccion.php?nom_marca=<?php echo $row_lineas['seccion']; ?>&subseccion=<?php echo $row_lineas['idseccion']; ?>" title="<?php echo $row_lineas['seccion']; ?>"> <?php echo ucwords(strtolower(recortar_texto_menu_detalle($row_lineas['seccion']))); ?></a></li>
                                <?php
                                    }
                                ?>                           
                                </ul>
                             </div>                  
                          
        
                          </div>
                          <div id="sidebarScrollable" class="sidebarMenu hidden">
                             <ul>
                                <?php
                                    $sql_marcas  = "SELECT * FROM marcas ORDER BY idmarca ASC";
                                    $rpta_marcas = query($sql_marcas) or die(mysql_error());
                                    
                                    while($row_marcas = fetch_array($rpta_marcas))
                                    {
                                    
                                ?>
                                <li><a href="marcas-jbg-electric-lima-peru.php?marca=<?php echo $row_marcas['idmarca']; ?>&nom_marca=<?php echo $row_marcas['nombre_marca']; ?>" title="<?php echo $row_marcas['nombre_marca']; ?>"><?php echo ucfirst(strtoupper($row_marcas['nombre_marca'])); ?></a></li>
                                <?php
                                    }
                                ?>                        
                             </ul>
                             
                          </div>
                       </div>
                       <!-- end of #sidebarMenu --> 
                       
                    </div>
                 </div>             
             	<div style="float:right; height:auto;">
                 <table width="638" border="0" cellpadding="0" cellspacing="0" align="right">
                    <tr class="titulos">
                       <td width="98" align="center">Imagen</td>
                       <td width="74" align="center">Codigo</td>
                       <td width="175" align="center">Producto</td>
                       <td width="113" align="center">Marca</td>
                       <td width="112" align="center"> Modelo</td>
                       <td width="98" align="center">Descripción</td>
                    </tr>
                    <tr>
                       <td height="5" colspan="6"></td>
                    </tr>
                    <?php	
                            while($row1 = fetch_array($resultado))
                            {
                       
                       ?>
                    <tr>
                       <td align="center" class="tdrow1">
                       <?php
                            if($row1['imagen']=="")
                            {
                                echo "<div style=\"heigth:47px; width:92px;\">no-foto</div>";
                            }
                            else
                            {
                       ?>
                                <img src="images/productos/<?php echo $row1['imagen']; ?>" width="75" height="75" />
                       <?php
                            }
                       ?>
                       </td>
                       <td align="center" class="tdrow1"><?php echo $row1['codigo_prod']; ?></td>
                       <td align="center" class="tdrow1"><?php echo $row1['nombre_producto']; ?></td>
                       <td align="center" class="tdrow1"><?php echo $row1['nombre_marca']; ?></td>
                       <td align="center" class="tdrow1"><?php echo $row1['modelo']; ?></td>
                       <td align="center" class="tdrow1"><a href="jbg-electric-detalle-producto-linea-lima-peru.php?idmarca=<?php echo $idmarca; ?>&idseccion=<?php echo $idseccion; ?>&nom_marca=<?php echo $nom_marca; ?>&seccion=<?php echo $seccion; ?>&subseccion=<?php echo $subseccion1; ?>&subnivel=<?php echo $subnivel; ?>&producto=<?php echo $row1['idproducto']; ?>#lineas" class="vermas_productos"><img src="images/ver-detalle.png" width="90" height="29" /></a></td>
                    </tr>
                    <?php
                            }
                       ?>
                 </table>
               </div>          
             </div>
            
            </div><!-- contenido_productos -->            
            
			<?php
                include("includes/lista-marcas.php");
                
            ?>
        
       </div><!-- cuerpo -->
       
		<?php
            include("includes/footer.php");
        
        ?>
       
    </div><!-- contenido -->



</div><!-- contenido_bg -->

</body>
<script type="text/javascript">

var so = new SWFObject("swf/banner.swf","flores","950","383","9");
 so.addParam("wmode", "transparent");
 so.addParam("menu", "false");
 so.write("banner");

</script>
<script type="text/javascript">

var so = new SWFObject("swf/logo.swf","miguelangoma","377","153","9");
 so.addParam("wmode", "transparent");
 so.addParam("menu", "false");
 so.write("header_logo");
</script>
</html>