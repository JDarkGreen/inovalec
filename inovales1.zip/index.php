
<!-- Incluir el header principal estilos cargados y demás -->
<?php  
  //activar item
  $active = 1;
  //setear el título
  $title = "JBG ELECTRIC | Equipos Electricos Peru,  repuestos electricos,  productos por linea, materiales instalaciones electricas industrial, automatizacion industrial, conductores electricos, equipo de media tension control y proteccion, equipos de seguridad y maniobra, ferreteria de electrificacion, iluminacion peru, instrumentos de medicion, linea conduit, materiales aislantes, materiales para instalaciones residenciales, pararrayos, sistema puesta tierra y afines, seguridad industrial lima peru, repuestos electricos lima peru, material construccion electricos,  productos por marcas 3m, lima abb abro aibar, bremas  celsa cirmarker lima, coel crc elcope lima, exosolda general electric indeco peru, kss legrand leviton peru, loctite lumnia mennekes peru, schneider electric siemens peru, talma ide termoweld lima, solera jsl santos peru dexson tecnoflex ls repuestos peru, tecnofil bticino orbis metal&a opalux hurricane lima peru";

  //incluir plantilla header
  include('includes/main-header.php');

?>

<!-- Banner Inicio -->
<section id="banner-home" class="sectionBanner">
  <img src="<?= IMAGES ?>/banner/home/inicio_bn_1.jpg" alt="inicio_bn_1" class="responsive-img" />
  <img src="<?= IMAGES ?>/banner/home/inicio_bn_2.jpg" alt="inicio_bn_2" class="responsive-img" />
  <img src="<?= IMAGES ?>/banner/home/inicio_bn_3.jpg" alt="inicio_bn_3" class="responsive-img" />
  <img src="<?= IMAGES ?>/banner/home/inicio_bn_4.jpg" alt="inicio_bn_4" class="responsive-img" />
</section> <!-- /end of banner -->

<!-- Linea separadora -->
<span class="line-separator"></span>

<!-- Sección de Promociones -->
<section class="sectionPortada__promociones">
  <div class="container">
    <h1 class="sectionCommon__title sectionCommon__title--border-blue text-uppercase">promociones</h1>

    <section class="sectionPortada__promociones__content relative">
      <div id="carousel-promociones" class="sectionPortada__promociones__content">
        <?php 
          $row_producto_promocion = fetch_array($rpta_listar_promocion); 
          foreach( $row_producto_promocion as $producto_promo ) :
        ?>
          <div class="item">
            <article class="sectionPortada__promociones__content__item relative">
              <h2 class="center text-uppercase"><?= $producto_promo['titulo_promocion']; ?></h2>
              <!-- Imagen -->
              <figure>
                <img class="center-block owl-lazy" data-src="images/productos/promociones/<?= $producto_promo['imagen_promocion']; ?>" />
              </figure><!-- /figure -->
              <!-- Boton cotizar -->
              <a href="" class="btn__cotizar">Cotizar</a>
            </article><!-- /article -->
          </div>
        <?php endforeach; ?>
        </div>

      <!-- Arrows -->
      <a class="carousel-promotion-arrow carousel-promotion-arrow--left waves-effect"><i class="material-icons">chevron_left</i></a>
      <a class="carousel-promotion-arrow carousel-promotion-arrow--right waves-effect"><i class="material-icons">chevron_right</i></a>
    </section><!-- /.sectionPortada__promociones__content -->
  </div> <!-- /.container -->
</section><!-- /.sectionPortada__promociones -->

<!-- Linea separadora -->
<span class="line-separator"></span>

<!-- Secciones de Informacion de Promociones -->
<section class="sectionPortada__nosotros">
  <div class="row">
    <article class="sectionPortada__nosotros__item col s12 m6">
        <!-- Imagen -->
        <figure>
          <img src="images/portada/sec-nosotros/inicio_bn_nosotros_1.jpg" alt="inicio_bn_nosotros_1" class="responsive-img" />
        </figure>
    </article><!-- /.sectionPortada__nosotros__item -->
    <article class="sectionPortada__nosotros__item sectionPortada__nosotros__item--desc col s12 m6">
      <!-- Imagen -->
        <figure>
          <img src="images/portada/sec-nosotros/inicio_bn_nosotros_2.jpg" alt="inicio_bn_nosotros_2" class="responsive-img" />
        </figure><!-- /figure -->
        <!-- Informacioón -->
        <div class="item-text">
          <h2 class="sectionCommon__title text-uppercase">nosotros</h2> <br/>
          <p class="sectionCommon__parragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione iure aut reprehenderit, cum impedit magni placeat unde cupiditate sed. Quibusdam tenetur, id corporis totam! Enim libero fugit facilis maiores nulla.</p>
          <!-- Boton ver más -->
          <br/>
          <a href="#" class="btn__more--orange right waves-effect">ver más</a>
          <!-- Clearfix --> <div class="clearfix"></div>
        </div><!-- /.item-text -->
    </article> <!-- /.sectionPortada__nosotros__item -->
  </div><!-- /.row -->
</section><!-- /.sectionPortada__nosotros -->

<!-- Seccion incluir marcas -->
<section class="sectionMarcas">
  <div class="container">
    <div id="owl-carousel-marcas" class="">
      <div class="item"><img src="images/carousel-marcas/marca-3m-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-abb-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-abro-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-aibar-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-amp-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-bahaco-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-bticino-jbg.jpg" alt="" class="responsive-img" /></div>
    </div><!-- /.owl-carousel -->
  </div><!-- /.container -->
</section><!-- /sectionMarcas -->


<!-- Incluir demás librerias javascript en el main footer -->
<?php include("includes/main-footer.php") ?>