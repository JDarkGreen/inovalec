
<!-- Incluir el header principal estilos cargados y demás -->
<?php  
  //activar item
  $active = 2;
  //setear el título
  $title = "JBG ELECTRIC | Historia de la empresa, Eventos, Equipos Electricos Peru,  repuestos electricos,  productos por linea, materiales instalaciones electricas industrial, automatizacion industrial, conductores electricos, equipo de media tension control y proteccion, equipos de seguridad y maniobra, ferreteria de electrificacion, iluminacion peru, instrumentos de medicion, linea conduit, materiales aislantes, materiales para instalaciones residenciales, pararrayos, sistema puesta tierra y afines, seguridad industrial lima peru, repuestos electricos lima peru, material construccion electricos,  productos por marcas 3m, lima abb abro aibar, bremas  celsa cirmarker lima, coel crc elcope lima, exosolda general electric indeco peru, kss legrand leviton peru, loctite lumnia mennekes peru, schneider electric siemens peru, talma ide termoweld lima, solera jsl santos peru dexson tecnoflex ls repuestos peru, tecnofil bticino orbis metal&a opalux hurricane lima peru";

  //incluir plantilla header
  include('includes/main-header.php');

?>

<!-- Incluir Banner de Pagina -->
<?php  
    $title_page = "empresa";
    $ruta_img   = "images/banner/nosotros_bn_principal.jpg";
    include("includes/page/banner.php");
?>

<!-- Linea separadora -->
<span class="line-separator"></span>

<!-- sectionHistoria Pagina Nosotros -->
<section class="sectionPage__nosotros__historia">
    <div class="mainWrapperPage">
        <div class="row">
            <div class="col s12 m6">
                <figure><img src="images/pages/nosotros/historia.jpg" alt="" class="responsive-img" /></figure>
            </div><!-- /.col s12 m6 -->
            <div class="col s12 m6">
                <h2 class="sectionPage__nosotros__title text-uppercase">historia</h2>
                <p class="sectionPage__nosotros__paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis asperiores excepturi deleniti iste repellendus nulla, non consequatur, unde eum voluptatum! Alias voluptates enim eius, illo quaerat sunt aut porro dolores!</p><p class="sectionPage__nosotros__paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis asperiores excepturi deleniti iste repellendus nulla, non consequatur, unde eum voluptatum! Alias voluptates enim eius, illo quaerat sunt aut porro dolores!</p><p class="sectionPage__nosotros__paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis asperiores excepturi deleniti iste repellendus nulla, non consequatur, unde eum voluptatum! Alias voluptates enim eius, illo quaerat sunt aut porro dolores!</p>
            </div><!-- /.col s12 m6 -->
        </div><!-- /.rpow -->
    </div><!-- /.container -->
</section><!-- /.sectionPage__nosotros__historia -->

<!-- sectionHistoria Pagina Nosotros -->
<section class="sectionPage__nosotros__aptitudes">
    <div class="mainWrapperPage">
        <div class="row">
            <article class="col s12 m6">
                <figure class="left"><img src="images/pages/nosotros/nosotros_mision.jpg" alt="" class="responsive-img"></figure>
                <h2 class="sectionPage__nosotros__title text-uppercase">misión</h2>
                <p class="sectionPage__nosotros__paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci odit qui, odio repellendus molestias est quas nobis commodi sint iure earum nulla repellat illum quisquam. Iusto officia asperiores nesciunt cum!</p>
            </article><!-- /.col s12 m6 -->
            <article class="col s12 m6">
                <figure class="left"><img src="images/pages/nosotros/nosotros_valores.jpg" alt="" class="responsive-img"></figure>
                <h2 class="sectionPage__nosotros__title text-uppercase">valores</h2>
                <p class="sectionPage__nosotros__paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci odit qui, odio repellendus molestias est quas nobis commodi sint iure earum nulla repellat illum quisquam. Iusto officia asperiores nesciunt cum!</p>                
            </article><!-- /.col s12 m6 -->
            <article class="col s12 m6">
                <figure class="left"><img src="images/pages/nosotros/nosotros_vision.jpg" alt="" class="responsive-img"></figure>
                <h2 class="sectionPage__nosotros__title text-uppercase">visión</h2>
                <p class="sectionPage__nosotros__paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci odit qui, odio repellendus molestias est quas nobis commodi sint iure earum nulla repellat illum quisquam. Iusto officia asperiores nesciunt cum!</p>
            </article><!-- /.col s12 m6 -->
            <article class="col s12 m6">
                <figure class="left"><img src="images/pages/nosotros/nosotros_filosofia.jpg" alt="" class="responsive-img"></figure>
                <h2 class="sectionPage__nosotros__title text-uppercase">filosofía</h2>
                <p class="sectionPage__nosotros__paragraph">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci odit qui, odio repellendus molestias est quas nobis commodi sint iure earum nulla repellat illum quisquam. Iusto officia asperiores nesciunt cum!</p>
            </article><!-- /.col s12 m6 -->
        </div> <!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.sectionPage__nosotros__aptitudes -->

<!-- Linea separadora -->
<span class="line-separator"></span>

<!-- Seccion incluir marcas -->
<section class="sectionMarcas">
  <div class="container">
    <div id="owl-carousel-marcas" class="">
      <div class="item"><img src="images/carousel-marcas/marca-3m-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-abb-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-abro-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-aibar-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-amp-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-bahaco-jbg.jpg" alt="" class="responsive-img" /></div>
      <div class="item"><img src="images/carousel-marcas/marca-bticino-jbg.jpg" alt="" class="responsive-img" /></div>
    </div><!-- /.owl-carousel -->
  </div><!-- /.container -->
</section><!-- /sectionMarcas -->

<!-- Incluir demás librerias javascript en el main footer -->
<?php include("includes/main-footer.php") ?>