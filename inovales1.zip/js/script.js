
var j = jQuery.noConflict();

(function($){
	j(document).on('ready',function(){

		//activador parallax
		j('.parallax').parallax();

		//activar carousel marcas
		j("#scroller").simplyScroll({ auto: true, speed: 3 });

		//activar SIDEMENU MATERIALIZE
		j('.button-collapse').sideNav({
			menuWidth   : 240,
		});
		

		/*|----------------------------------------------------------------------|*/
		/*|-----  CAROUSEL HOME LIBRERIA CUBESLIDER ------|*/
		/*|----------------------------------------------------------------------|*/
		j("#banner-home").cubeslider({
			cubesNum   : {rows:4, cols:1},
			cubeSync   : 300,
			navigation : false,
			orientation: 'h',
			play       : false,
		});

		/*|----------------------------------------------------------------------|*/
		/*|-----  CAROUSEL PROMOCIONES  ------|*/
		/*|----------------------------------------------------------------------|*/
		var carousel_promo = j("#carousel-promociones").owlCarousel({
			items     : 4,
			lazyLoad  : true,
			loop      : true,
			margin    : 10,
			nav       : false,
			autoplay  : true,
			fluidSpeed: 500,
			smartSpeed: 600,
			responsive:{
		        320:{
		            items:1
		        },
		      	1024:{
		            items:4
		        },
	    	}
		});

		j(".carousel-promotion-arrow--left").on('click',function(e){
			e.preventDefault();
			carousel_promo.trigger('prev.owl.carousel');
		});		
		j(".carousel-promotion-arrow--right").on('click',function(e){
			e.preventDefault();
			carousel_promo.trigger('next.owl.carousel');
		});

		/*|----------------------------------------------------------------------|*/
		/*|-----  CAROUSEL MARCAS  ------|*/
		/*|----------------------------------------------------------------------|*/
		var carousel_marcas = j("#owl-carousel-marcas").owlCarousel({
			items     : 6,
			lazyLoad  : true,
			loop      : true,
			margin    : 12,
			nav       : false,
			autoplay  : true,
			fluidSpeed: 500,
			smartSpeed: 600,
			responsive:{
		        320:{
		            items:3
		        },
		      	1024:{
		            items:6
		        },
	    	}
		});

	});
})(jQuery)